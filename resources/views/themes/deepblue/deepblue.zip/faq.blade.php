@extends($theme.'layouts.app')
@section('title', trans('FAQ'))

@section('content')

    @include($theme.'sections.faq')

@endsection
